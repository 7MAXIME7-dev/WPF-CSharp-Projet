﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    abstract class Evènement
    {
        string nom;
        DateTime début;
        int duree;

        public Evènement(string nom, DateTime début, int duree)
        {
            this.nom = nom;
            this.début = début;
            this.duree = duree;
        }

        public string Nom { get { return this.nom; } }
        public DateTime Début { get { return this.début; } }
        public int Duree { get { return duree; } }

        public override string ToString()
        {
            DateTime fin = début.AddDays(duree);
            return Nom + " débutera le " + début.Day + "/" + début.Month + "/" + début.Year + " et finira le " + fin.Day + "/" + fin.Month + "/" + fin.Year;
        }
      

        
    }
}
