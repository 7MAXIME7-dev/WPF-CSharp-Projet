﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    abstract class Acteur : ICalculsDate
    {

        string nom;
        string prenom;
        DateTime dateNaissance;
        string adresse;
        string numero;
        char sexe;

        public Acteur(string nom, string prenom, DateTime dateNaissance, string adresse, string numero, char sexe)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.dateNaissance = dateNaissance;
            this.adresse = adresse;
            this.numero = numero;
            this.sexe = sexe;
        }

        public string Nom { get { return this.nom.ToUpper(); } }
        public string Prenom { get { return this.prenom; } }
        public DateTime DateNaissance { get { return this.dateNaissance; } }
        public string Adresse { get { return this.adresse; } set { this.adresse = value; } }
        public string Numero { get { return this.numero; } set { this.numero = value; } }
        public char Sexe { get { return this.sexe; } }


        /// <summary>
        /// Calule l'age d'une personne
        /// </summary>
        /// <returns>l'age (interger) </returns>
        public int Age()
        {
            return DateTime.Now.Year - this.dateNaissance.Year;
        }

        /// <summary>
        /// Permet d'afficher une date
        /// </summary>
        /// <param name="d"> date à convertir</param>
        /// <returns>la date sous forme DD/MM/AAAA (string)</returns>
        public string DateToString(DateTime d)
        {
            string date = d.Day + "/" + d.Month + "/" + d.Year;
            return date;
        }

         


        public override string ToString()
        {
            return "\nNom                          : " + this.nom
                 + "\nPrenom                       : " + this.prenom
                 + "\nDate de naissance (JJ/MM/AA) : " + this.DateToString(this.DateNaissance)
                 + "\nAdresse postale              : " + this.adresse;
        }


    }

}
