﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    interface IOutilsStatistique
    {
        public Tuple<int, int> NbDeCompetitionRéalisésOuResteAFaire();
        public SortedList<string, int[]> NbMatchParMembre();
        public double NbMoyenJoueurCompétitionVsLoisir();
        public SortedList<int, int[]> NbMatchGagnéVsPerduParAnnée();
        public SortedList<char, int[]> NbMatchGagnéVsPerduParCatégorie();
        public object ProchainEvenement();
    }
}
