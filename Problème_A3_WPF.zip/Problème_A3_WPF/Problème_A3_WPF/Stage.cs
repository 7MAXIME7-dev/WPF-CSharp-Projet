﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class Stage : Evènement
    {
        int prixParPersonne;
        List<string> jeunesStagiaire;
        string entraineur;
       

        public Stage(string nom, DateTime début, int duree, int prixParPersonne,string entraineur, List<string> jeunesStagiaire)
            :base(nom, début, duree)
        {
            this.prixParPersonne = prixParPersonne;
            this.jeunesStagiaire = jeunesStagiaire;
            this.entraineur = entraineur;
            
        }

        public int PrixParPersonne { get { return this.prixParPersonne; } }
        public List<string> JeunesStagiaire { get { return this.jeunesStagiaire; } set { this.jeunesStagiaire = value; } }

        public override string ToString()
        {
            return "Stage " + base.ToString();
        }


    }
}
