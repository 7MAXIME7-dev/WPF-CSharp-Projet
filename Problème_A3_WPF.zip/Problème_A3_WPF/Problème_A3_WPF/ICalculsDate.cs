﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    interface ICalculsDate
    {
        public int Age();

        public string DateToString(DateTime d);
    }
}
