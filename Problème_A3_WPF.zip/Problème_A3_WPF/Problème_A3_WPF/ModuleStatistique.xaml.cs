﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour Bilan.xaml
    /// </summary>
    public partial class ModuleStatistique : Window
    {
        Club leClub;
        SortedList<string, int[]> nbMatchParMembre;
        SortedList<int, int[]> nbMatchPvsGParAnnee;
        SortedList<char, int[]> nbMatchPvsGParCategorie;

        /// <summary>
        /// Constructeur pour la fenetre Statistique du club
        /// </summary>
        public ModuleStatistique()
        {
            this.leClub = new Club();
            this.nbMatchParMembre = leClub.NbMatchParMembre();
            this.nbMatchPvsGParAnnee = leClub.NbMatchGagnéVsPerduParAnnée();
            this.nbMatchPvsGParCategorie = leClub.NbMatchGagnéVsPerduParCatégorie();
            InitializeComponent();
            AfficherCompetition();
            AfficherMatchs();
            AfficherAnnee();
            AfficherCatégorie();
        }

        /// <summary>
        /// Affichage de la partie Compétition 
        /// </summary>
        private void AfficherCompetition()
        {
            Tuple<int, int> infos = leClub.NbDeCompetitionRéalisésOuResteAFaire();
            ShowCompetReal.Text = infos.Item1.ToString();
            ShowCompetToDo.Text = infos.Item2.ToString();
        }

        /// <summary>
        /// Affichage des Joueurs dans la partie Match
        /// </summary>
        private void AfficherMatchs()
        {
            ShowCompetiteur.ItemsSource = nbMatchParMembre.Keys;
            ShowCompetiteur.SelectedIndex = 0;
        }

        /// <summary>
        /// Affichage des années dans la partie "Par Année" 
        /// </summary>
        private void AfficherAnnee()
        {
            ShowAnnee.ItemsSource = nbMatchPvsGParAnnee.Keys;
            ShowAnnee.SelectedIndex = 0;
        }

        /// <summary>
        /// Affichage des années dans la partie "Par Catégorie" 
        /// </summary>
        private void AfficherCatégorie()
        {
            ShowCategorie.ItemsSource = nbMatchPvsGParCategorie.Keys;
            ShowCategorie.SelectedIndex = 0;
        }

        /// <summary>
        /// Affiche les infos lié au joueur selectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_Compétiteur(object sender, SelectionChangedEventArgs e)
        {
            int[] values = nbMatchParMembre[ShowCompetiteur.SelectedItem.ToString()];
            ShowMCJ.Text = values[0].ToString();
            ShowMCG.Text = values[1].ToString();
            ShowMCP.Text = values[2].ToString();
        }

        /// <summary>
        /// Affiche les infos lié à l'année selectionné 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_Annee(object sender, SelectionChangedEventArgs e)
        {
            int[] values = nbMatchPvsGParAnnee[Convert.ToInt32(ShowAnnee.SelectedItem)];
            ShowRAG.Text = values[0].ToString();
            ShowRAP.Text = values[1].ToString();
        
        }

        /// <summary>
        ///  Affiche les infos lié à la catégorie selectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_Catégorie(object sender, SelectionChangedEventArgs e)
        {
            int[] values = nbMatchPvsGParCategorie[Convert.ToChar(ShowCategorie.SelectedItem)];
            ShowRCG.Text = values[0].ToString();
            ShowRCP.Text = values[1].ToString();
        }

        /// <summary>
        /// ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
