﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class Personnel : Acteur
    {
        string rib;
        int salaire;
        DateTime dateEntree;

        //true=salarié false=independant
        bool estSalarié;

        //true= entraineur flase=autres
        bool estEntraineur;

        public Personnel(string nom, string prenom, DateTime dateNaissance, string adresse, string numero,
            char sexe, string rib, int salaire, bool estSalarié, bool estEntraineur, DateTime dateEntree) 
            : base(nom, prenom, dateNaissance, adresse, numero, sexe)
        {
            this.rib = rib;
            this.salaire = salaire;
            this.dateEntree = dateEntree;
            this.estEntraineur = estEntraineur;
            this.estSalarié = estSalarié;
        }

        public string Rib { get { return rib.ToUpper(); } }
        public int Salaire { get { return salaire; } }
        public DateTime DateEntree { get { return dateEntree; } }

        public bool EstEntraineur { get { return this.estEntraineur; } }
        public bool EstSalarié { get { return this.estSalarié; } }
    }
}
