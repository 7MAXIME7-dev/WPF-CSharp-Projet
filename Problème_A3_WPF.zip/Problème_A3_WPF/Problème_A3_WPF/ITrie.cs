﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    interface ITrie
    {
        public void TrieOrdreAlphabétique();
        public int TrieParSexe(bool estHomme);
        public int TrieParDoitPayer();
        public int TrieLoisirCompetition(bool estLoisir);
        public int TrieJunior();
        public void TrieClassement();
    }
}
