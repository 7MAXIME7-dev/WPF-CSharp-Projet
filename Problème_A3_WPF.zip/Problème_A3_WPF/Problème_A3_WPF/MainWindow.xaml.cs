﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        /// <summary>
        /// Contructeur fenetre principale (tableau de bord)
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            Club leclub = new Club();
            if(leclub.ProchainEvenement() != null)
                ShowProchain.Text = "\n  " + leclub.ProchainEvenement().ToString();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            GestionMembre M = new GestionMembre();            
            M.Show(); 
            
        }

        private void Button_gerer_salarie(object sender, RoutedEventArgs e)
        {
            GestionPersonnel S = new GestionPersonnel();
            S.Show();
        }

        private void Button_Inscrire(object sender, RoutedEventArgs e)
        {
            InscrireQui Q = new InscrireQui();
            Q.Show();
        }

        private void Button_Voir_Comptetition(object sender, RoutedEventArgs e)
        {
            GestionCompétition C = new GestionCompétition();
            C.Show();
        }

        private void Button_new_Comptetition(object sender, RoutedEventArgs e)
        {
            NouvelleCompetition NC = new NouvelleCompetition();
            NC.Show();
        }

        private void Button_Voir_Bilan(object sender, RoutedEventArgs e)
        {
            ModuleStatistique M = new ModuleStatistique();
            M.Show();
        }

        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void TextBox_ProchainEveneme(object sender, TextChangedEventArgs e)
        {
        }
    }
}
