﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Problème_A3_WPF
{
    class Club : ILectureEcritureFichierTxt, ITrie, IOutilsStatistique
    {
        List<Membre> lesMembres;
        List<Personnel> lePersonnel;
        List<Competition> lesCompétitions;
        List<Stage> lesStages;
        
        static string SalariésFileName = "Personnel.txt";
        static string MembresFileName = "Membres.txt";
        static string CompétitionsFileName = "Compétitions.txt";
        static string StagesFileName = "Stages.txt";

        public Club()
        {
            this.lesMembres = LectureFichierMembre();
            this.lePersonnel = LectureFichierPersonnel();
            this.lesCompétitions = LectureFichierCompetitions();
            this.lesStages = LectureFichierStages();
        }

        public List<Membre> LesMembres { get { return this.lesMembres; } }
        public List<Personnel> LePersonnel { get { return this.lePersonnel; } }
        public List<Competition> LesCompétitions { get { return this.lesCompétitions; } }



        #region Opérations sur les dates
        public DateTime CreationDate(int jour, int mois, int annee)
        {
            DateTime date = new DateTime(day: jour, month: mois, year: annee);
            return date;
        }

        /// <summary>
        /// permet d'isoler chaque chiffre de la date 
        /// </summary>
        /// <param name="date">date sous forme de tableau isolant chaque chiffre</param>
        /// <returns>tableau d'entier</returns>
        public List<int> ToIntDate(string[] date)
        {
            // convertion des elements string en int
            List<int> intdate = new List<int>();
            foreach (string e in date) { intdate.Add(Convert.ToInt32(e)); }

            return intdate;
        }

        /// <summary>
        /// obtenir le prochain evenement
        /// </summary>
        /// <returns>une compétition ou stage ou tournois ludique </returns>
        public object ProchainEvenement()
        {         
            lesCompétitions.Sort((a, b) => -a.Début.CompareTo(b.Début));
            lesStages.Sort((a, b) => -a.Début.CompareTo(b.Début));

            TimeSpan d = lesCompétitions[0].Début - lesStages[0].Début;
            if (d.TotalDays > 0)
            {
                if ((DateTime.Now - lesCompétitions[0].Début).TotalDays < 0)
                    return lesCompétitions[0];
                else
                    return null;
            }
            else
            {
                if ((DateTime.Now - lesCompétitions[0].Début).TotalDays < 0)
                    return lesStages[0];
                else
                    return null;
            }
        }

        #endregion



        #region Lecture/écriture des fichiers txt


        /// <summary>
        /// Lit le fichier des informations sur les Membres
        /// </summary>
        /// <returns>liste des Membres</returns>
        public List<Membre> LectureFichierMembre()
        {
            List<Membre> Memb = new List<Membre>();
            //Pass the file path and file name to the StreamReader constructor
            StreamReader sr = new StreamReader(MembresFileName);

            string line;
            while (sr.Peek() > 0)
            {
                line = sr.ReadLine();
                string[] elements = line.Split(';');
                List<int> intdate = ToIntDate(elements[2].Split('/'));

                Membre m = new Membre(elements[0], elements[1], CreationDate(intdate[0], intdate[1], intdate[2]),
                    elements[3], elements[4], Convert.ToBoolean(elements[5]), Convert.ToBoolean(elements[6]), Convert.ToChar(elements[7]), elements[8], elements[9]);

                m.CotisationPaye = Convert.ToBoolean(elements[10]);
                Memb.Add(m);
            }
            //close the file
            sr.Close();

            return Memb;
        }

        /// <summary>
        ///  lit le fichier des informations sur les Salariés
        /// </summary>
        /// <returns>liste des Salariés</returns>
        public List<Personnel> LectureFichierPersonnel()
        {
            List<Personnel> Sala = new List<Personnel>();
            //Pass the file path and file name to the StreamReader constructor
            StreamReader sr = new StreamReader(SalariésFileName);

            string line;
            while (sr.Peek() > 0)
            {
                line = sr.ReadLine();
                string[] elements = line.Split(';');
                List<int> date_naissance = ToIntDate(elements[2].Split('/'));
                List<int> date_entree = ToIntDate(elements[10].Split('/'));

                Personnel m = new Personnel(elements[0], elements[1], CreationDate(date_naissance[0], date_naissance[1], date_naissance[2]),
                    elements[3], elements[4], Convert.ToChar(elements[5]), elements[6], Convert.ToInt32(elements[7]),
                     bool.Parse(elements[8]), bool.Parse(elements[9]), CreationDate(date_entree[0], date_entree[1], date_entree[2]));

                Sala.Add(m);
            }
            //close the file
            sr.Close();

            return Sala;
        }

        /// <summary>
        /// Enregistre le fichier des informations sur les Membres
        /// </summary>
        public void EnregistrementFichierMembre()
        {
            File.Delete(MembresFileName);
            File.CreateText(MembresFileName).Close();
            StreamWriter fichEcr = new StreamWriter(MembresFileName, true);


            int count = lesMembres.Count;
            for (int i = 0; i < lesMembres.Count; i++)
            {
                fichEcr.WriteLine(
                    lesMembres[i].Nom + ";" + lesMembres[i].Prenom + ";" + lesMembres[i].DateToString(lesMembres[i].DateNaissance) + ";"
                    + lesMembres[i].Adresse + ";" + lesMembres[i].Numero + ";" + lesMembres[i].HabiteDansVilleDuClub + ";"
                    + lesMembres[i].EnCompetiton + ";" + lesMembres[i].Sexe + ";" + lesMembres[i].Classement + ";" + lesMembres[i].Mail + ";" + lesMembres[i].CotisationPaye);
            }

            fichEcr.Close();
        }

        /// <summary>
        /// Enregistre le fichier des informations sur les Salariés
        /// </summary>
        public void EnregistrementFichierPersonnel()
        {
            File.Delete(SalariésFileName);
            File.CreateText(SalariésFileName).Close();
            StreamWriter fichEcr = new StreamWriter(SalariésFileName, true);

            int count = lePersonnel.Count;
            for (int i = 0; i < lePersonnel.Count; i++)
            {
                fichEcr.WriteLine(
                    lePersonnel[i].Nom + ";" + lePersonnel[i].Prenom + ";" + lePersonnel[i].DateToString(lePersonnel[i].DateNaissance) + ";"
                    + lePersonnel[i].Adresse + ";" + lePersonnel[i].Numero + ";" + lePersonnel[i].Sexe + ";" + lePersonnel[i].Rib + ";"
                    + lePersonnel[i].Salaire + ";" + lePersonnel[i].EstSalarié + ";" + lePersonnel[i].EstEntraineur + ";" + lePersonnel[i].DateToString(lePersonnel[i].DateEntree));
            }

            fichEcr.Close();
        }

        /// <summary>
        ///  Lit le fichier des informations sur les Compétitions
        /// </summary>
        /// <returns>Liste des Compétitions</returns>
        public List<Competition> LectureFichierCompetitions()
        {
            List<Competition> Compets = new List<Competition>();

            //Pass the file path and file name to the StreamReader constructor
            StreamReader sr = new StreamReader(CompétitionsFileName);



            string line;
            while (sr.Peek() > 0)
            {
                List<Match> lesMatchs = new List<Match>();
                line = sr.ReadLine();
                string[] elements = line.Split('_');

                string[] eltCompet = elements[0].Split(';');

                List<int> dateDébut = ToIntDate(eltCompet[5].Split('/'));

                for (int i = 1; i < elements.Length; i++)
                {
                    string[] eltMatch = elements[i].Split(';');
                    List<int> dateRencontre = ToIntDate(eltMatch[4].Split('/'));

                    Match leMatch = new Match(eltMatch[0], eltMatch[1], int.Parse(eltMatch[2]), bool.Parse(eltMatch[3]),
                        CreationDate(dateRencontre[0], dateRencontre[1], dateRencontre[2]));

                    lesMatchs.Add(leMatch);
                }


                Competition laCompet = new Competition(eltCompet[0], char.Parse(eltCompet[1]), eltCompet[2], int.Parse(eltCompet[3]), int.Parse(eltCompet[4]),
                    CreationDate(dateDébut[0], dateDébut[1], dateDébut[2]), eltCompet[6], lesMatchs);

                Compets.Add(laCompet);
            }
            //close the file
            sr.Close();

            return Compets;
        }

        /// <summary>
        /// Enregistre le fichier des informations sur les Compétitions
        /// </summary>
        public void EnregistrementFichierCompetitions()
        {
            File.Delete(CompétitionsFileName);
            File.CreateText(CompétitionsFileName).Close();
            StreamWriter fichEcr = new StreamWriter(CompétitionsFileName, true);

            for (int i = 0; i < lesCompétitions.Count; i++)
            {
                Competition comp = lesCompétitions[i];

                fichEcr.Write(comp.Nom + ";" + comp.Catégorie + ";" + comp.Niveau + ";" + comp.NbJoueursMin + ";" + comp.Duree + ";" + comp.DateDébutToString() + ";" + comp.ClassementMax);


                for (int j = 0; j < comp.Matchs.Count; j++)
                {
                    Match ma = comp.Matchs[j];
                    fichEcr.Write("_" + ma.NomJoueur + ";" + ma.PrenomJoueur + ";" + ma.ResultatRencontre + ";" + ma.EstSimple + ";" + ma.DateDeRencontreToString());
                }

                fichEcr.WriteLine();
            }

            fichEcr.Close();
        }

        public List<Stage> LectureFichierStages()
        {
            List<Stage> stages = new List<Stage>();
            
            //Pass the file path and file name to the StreamReader constructor
            StreamReader sr = new StreamReader(StagesFileName);

            string line;
            while (sr.Peek() > 0)
            {
                line = sr.ReadLine();
                string[] elements = line.Split('_');
                string[] infoStage = elements[0].Split(';');

                List<int> intdate = ToIntDate(infoStage[1].Split('/'));
                string[] nom = elements[1].Split(';');
                List<string> lesNom = nom.ToList();

                Stage st = new Stage(infoStage[0], CreationDate(intdate[0], intdate[1], intdate[2]), int.Parse(infoStage[2]), int.Parse(infoStage[3]),infoStage[4], lesNom);
     
                stages.Add(st);
            }
            //close the file
            sr.Close();

            return stages;
        }

        #endregion


        #region Trie pour le Module Membre

        /// <summary>
        /// Trie la liste des Membres suivant l'ordre Alphabétique
        /// </summary>
        public void TrieOrdreAlphabétique()
        {
            lesMembres.Sort((a, b) => a.Nom.CompareTo(b.Nom));
        }

        /// <summary>
        /// Trie la liste des Membres suivant le sexe, A chaque appel il y a triage soit des hommes soit des femmes
        /// </summary>
        /// <param name="estHomme">(bool) si true, récupère les hommes</param>
        /// <returns>le nombre d'homme ou le nombre de femme</returns>
        public int TrieParSexe(bool estHomme)
        {
            List<Membre> M = lesMembres.FindAll(a => a.Sexe == 'M');
            List<Membre> F = lesMembres.FindAll(a => a.Sexe == 'F');

            if (estHomme)
            {
                this.lesMembres = M.Concat(F).ToList();
                return M.Count;
            }
            else
            {
                this.lesMembres = F.Concat(M).ToList();
                return F.Count;
            }    
        }

        /// <summary>
        /// Trie la liste des Membres pour mettre en tête de liste ce qui doivent payer
        /// </summary>
        /// <returns>nombre de personne qui doivent payer</returns>
        public int TrieParDoitPayer()
        {
            List<Membre> pasPayé= lesMembres.FindAll(a => a.CotisationPaye == false);
            List<Membre> estPayé = lesMembres.FindAll(a => a.CotisationPaye == true);

            lesMembres = pasPayé.Concat(estPayé).ToList();

            return pasPayé.Count;
        }

        /// <summary>
        /// Trie la liste des Membres pour mettre en tête de liste ce qui sont en compétition OU ce qui sont en loisir
        /// </summary>
        /// <param name="estLoisir">(bool) true si on souhaite récupérer ce en loisir</param>
        /// <returns>nombre de personne en loisir OU en compétition</returns>
        public int TrieLoisirCompetition(bool estLoisir)
        {
            List<Membre> Loisir = lesMembres.FindAll(a => a.EnCompetiton == false);
            List<Membre> Competition = lesMembres.FindAll(a => a.EnCompetiton == true);

            if (estLoisir)
            {
                this.lesMembres = Loisir.Concat(Competition).ToList();
                return Loisir.Count;
            }
            else
            {
                this.lesMembres = Competition.Concat(Loisir).ToList();
                return Competition.Count;
            }
        }

        /// <summary>
        /// (n'est pas utilisé)
        /// </summary>
        /// <returns></returns>
        public int TrieJunior()
        {
            List<Membre> junior = lesMembres.FindAll(a => a.Age() < 18);
            List<Membre> majeures = lesMembres.FindAll(a => a.Age() >= 18);
            this.lesMembres = junior.Concat(majeures).ToList();

            return junior.Count;
        }


        /// <summary>
        /// True la liste des Membres par leur classement (ordre : du pire au meilleur)
        /// </summary>                                             
        public void TrieClassement()
        {
            List<Membre> lesTop100 = lesMembres.FindAll(a => a.Classement == "TOP100");
            List<Membre> lesNC = lesMembres.FindAll(a => a.Classement == "NC");
            List<Membre> lesAutres = lesMembres.FindAll(a => a.Classement != "TOP100" && a.Classement != "NC");
            lesAutres.Sort();

            lesMembres = lesNC.Concat(lesAutres).Concat(lesTop100).ToList();
        }

        #endregion


        #region Outils pour le Module Statistique

        /// <summary>
        ///  permet de connaitre le nb de compétitions réalisés et restent à faire
        /// </summary>
        /// <returns>Tuple composé de 2 entier (nb réalisés, nb reste à faire)</returns>
        public Tuple<int,int> NbDeCompetitionRéalisésOuResteAFaire()
        {
            int realisés = 0;
            int resteAfaire = 0;
            foreach(Competition com in this.lesCompétitions)
            {
                if ((DateTime.Now - com.Début.AddDays(com.Duree)).Days > 0)
                {
                    realisés++;
                }
                else
                {
                    resteAfaire++;
                }
            }

            return Tuple.Create(realisés, resteAfaire);
        }

        /// <summary>
        /// Permet de connaitre pour chaque joueur (ayant participé à une compétition) le nb de match joués/gagnés/perdus 
        /// </summary>
        /// <returns>une SortedList avec key: nom du joueur / values : tableau d'entier contenant les 3 valeurs</returns>
        public SortedList<string, int[]> NbMatchParMembre()
        {
            SortedList<string, int[]> nbMatchParMembre = new SortedList<string, int[]>();

            foreach(Competition comp in this.lesCompétitions)
            {
                foreach(Match mat in comp.Matchs)
                {
                    string memberName = mat.PrenomJoueur + " " + mat.NomJoueur;


                    //si match est passé
                    if ((DateTime.Now - mat.DateDeRencontre).Days > 0)
                    {
                        // si la liste contient le membre
                        if (nbMatchParMembre.ContainsKey(memberName))
                        {

                            // le match est joué donc +1
                            nbMatchParMembre[memberName][0] = nbMatchParMembre[memberName][0] + 1;

                            // ajouter une victoire ou défaite
                            if (mat.ResultatRencontre == 0) { nbMatchParMembre[memberName][2] = nbMatchParMembre[memberName][2] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { nbMatchParMembre[memberName][1] = nbMatchParMembre[memberName][1] + 1; }

                        }

                        //si la liste ne contient pas le membre
                        else
                        {
                            int[] scores = { 0, 0, 0 };

                            if (mat.ResultatRencontre == 0) { scores[2] = scores[2] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { scores[1] = scores[1] + 1; }

                            nbMatchParMembre.Add(mat.PrenomJoueur + " " + mat.NomJoueur, scores);
                            nbMatchParMembre[memberName][0] = nbMatchParMembre[memberName][0] + 1;

                        }
                    }
                }
            }

            return nbMatchParMembre;
        }
     
        /// <summary>
        /// (non réalisé car consigne incomprise)
        /// </summary>
        /// <returns></returns>
        public double NbMoyenJoueurCompétitionVsLoisir()
        {
            return 0.0;
        }

        /// <summary>
        /// obtenir par année le nombre de match gagnés et perdus
        /// </summary>
        /// <returns>une SortedList avec key: l'année / values: un tableau de 2 valeurs </returns>
        public SortedList<int, int[]> NbMatchGagnéVsPerduParAnnée()
        {
            SortedList<int, int[]> matchsGagnéPerdu = new SortedList<int, int[]>();

            foreach (Competition comp in this.lesCompétitions)
            {
                foreach (Match mat in comp.Matchs)
                {
                    int year = mat.DateDeRencontre.Year;


                    //si match est passé
                    if ((DateTime.Now - mat.DateDeRencontre).Days > 0)
                    {
                        // si la liste contient le membre
                        if (matchsGagnéPerdu.ContainsKey(year))
                        {
                            // ajouter une victoire ou défaite
                            if (mat.ResultatRencontre == 0) { matchsGagnéPerdu[year][1] = matchsGagnéPerdu[year][1] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { matchsGagnéPerdu[year][0] = matchsGagnéPerdu[year][0] + 1; }

                        }

                        //si la liste ne contient pas le membre
                        else
                        {
                            int[] result = { 0, 0 };

                            if (mat.ResultatRencontre == 0) { result[1] = result[1] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { result[0] = result[0] + 1; }

                            matchsGagnéPerdu.Add(year, result);

                        }
                    }
                }
            }
            return matchsGagnéPerdu;
        }

        /// <summary>
        ///  obtenir par catégorie le nombre de match gagnés et perdus
        /// </summary>
        /// <returns>une SortedList avec key: la catégorie / values: un tableau de 2 valeurs </returns>
        public SortedList<char, int[]> NbMatchGagnéVsPerduParCatégorie()
        {
            SortedList<char, int[]> matchsGagnéPerdu = new SortedList<char, int[]>();

            foreach (Competition comp in this.lesCompétitions)
            {
                char catégorie = comp.Catégorie;


                foreach (Match mat in comp.Matchs)
                {
                  
                    //si match est passé
                    if ((DateTime.Now - mat.DateDeRencontre).Days > 0)
                    {
                        // si la liste contient le membre
                        if (matchsGagnéPerdu.ContainsKey(catégorie))
                        {
                            // ajouter une victoire ou défaite
                            if (mat.ResultatRencontre == 0) { matchsGagnéPerdu[catégorie][1] = matchsGagnéPerdu[catégorie][1] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { matchsGagnéPerdu[catégorie][0] = matchsGagnéPerdu[catégorie][0] + 1; }

                        }

                        //si la liste ne contient pas le membre
                        else
                        {
                            int[] result = { 0, 0 };

                            if (mat.ResultatRencontre == 0) { result[1] = result[1] + 1; }
                            if (mat.ResultatRencontre == 2 || mat.ResultatRencontre == 1) { result[0] = result[0] + 1; }

                            matchsGagnéPerdu.Add(catégorie, result);

                        }
                    }
                }
            }
            return matchsGagnéPerdu;
        }


        #endregion
    }
}
