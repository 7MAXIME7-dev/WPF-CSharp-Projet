﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class Match
    {
        string nomJoueur;
        string prenomJoueur;

        // victoire; défaite; annulation; -2 = non joué
        int resultatRencontre;
        // simple = true ; double = false
        bool estSimple;
        DateTime dateDeRencontre;


        public Match(string nomJoueur, string prenomJoueur,int resultatRencontre, bool estSimple, DateTime DateDeRencontre)            
        {
            this.nomJoueur = nomJoueur;
            this.prenomJoueur = prenomJoueur;
            this.resultatRencontre = resultatRencontre;
            this.estSimple = estSimple;
            this.dateDeRencontre = DateDeRencontre;
        }

        public string NomJoueur { get { return this.nomJoueur.ToUpper(); } }
        public string PrenomJoueur { get { return this.prenomJoueur; } }
        public int ResultatRencontre { get { return this.resultatRencontre; } set { this.resultatRencontre = value; } }
        public bool EstSimple { get { return this.estSimple; } }
        public DateTime DateDeRencontre { get { return this.dateDeRencontre; } }


        public string DateDeRencontreToString()
        {
            return dateDeRencontre.Day + "/" + dateDeRencontre.Month + "/" + dateDeRencontre.Year;
        }
    }
}
