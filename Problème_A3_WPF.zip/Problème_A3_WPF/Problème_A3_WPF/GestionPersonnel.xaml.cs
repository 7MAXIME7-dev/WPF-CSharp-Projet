﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour GestionPersonnel.xaml
    /// </summary>
    public partial class GestionPersonnel : Window
    {
        Club leClub;

        /// <summary>
        /// Constructeur pour la fenetre des Salariés
        /// </summary>
        public GestionPersonnel()
        {
            this.leClub = new Club(); 

            InitializeComponent();
        

            if(this.leClub.LePersonnel.Count != 0)
            {
                foreach (Personnel s in this.leClub.LePersonnel){ ListeDesMembres.Items.Add(s.Prenom + " " + s.Nom); }
                ListeDesMembres.SelectedItem = this.leClub.LePersonnel[0].Prenom + " " + this.leClub.LePersonnel[0].Nom;
            }
            else
            {
                MessageBox.Show("Aucun Membre !");                
            }                                               
        }

        /// <summary>
        /// Affiche les informations du salarié sélectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {    
           
            int index_selectionne = ListeDesMembres.SelectedIndex;

            if (index_selectionne >= 0)
            {
                Personnel information = this.leClub.LePersonnel[index_selectionne];

                ShowNom.Text = information.Nom;
                ShowPrenom.Text = information.Prenom;
                ShowAdresse.Text = information.Adresse;
                ShowDdn.Text = information.DateToString(information.DateNaissance);
                ShowNumero.Text = information.Numero;
                ShowRib.Text = information.Rib;
                ShowSalaire.Text = information.Salaire.ToString();
                ShowDateEntree.Text = information.DateToString(information.DateEntree);
                ShowEstEntraineur.Text = information.EstEntraineur.ToString();
                ShowEstSalarié.Text = information.EstSalarié.ToString();

            }

        }

        /// <summary>
        ///  Supprime un salarié
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Suppr_Click(object sender, RoutedEventArgs e)
        {
            Personnel selected = this.leClub.LePersonnel[ListeDesMembres.SelectedIndex];
            this.leClub.LePersonnel.Remove(selected);
            ListeDesMembres.Items.Remove(selected.Prenom + " " + selected.Nom);
        }

        /// <summary>
        /// ferme la fenêtre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// enregistre le fichier txt salarié puis ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Enregistrer(object sender, RoutedEventArgs e)
        {
            leClub.EnregistrementFichierPersonnel();
            Close();
        }

        /// <summary>
        /// Permet de changer l'adresse d'un obj Salarié
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Changer_Adresse(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Personnel information = this.leClub.LePersonnel[index_selectionne];
            information.Adresse = ShowAdresse.Text;
        }

        /// <summary>
        /// Permet de changer le numéro d'un obj Salarié
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Changer_Numero(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Personnel information = this.leClub.LePersonnel[index_selectionne];
            information.Numero= ShowNumero.Text;
        }
    }
}
