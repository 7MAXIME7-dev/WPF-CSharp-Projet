﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour NouvelleCompetition.xaml
    /// </summary>
    public partial class NouvelleCompetition : Window
    {
        static string CompétitionFileName = "Compétitions.txt";

        /// <summary>
        /// Constructeur pour la fenetre nouvelle Competition
        /// </summary>
        public NouvelleCompetition()
        {
            InitializeComponent();
        }


        /// <summary>
        /// Récupération des éléments saisies, création de l'obj Compétition puis inscription sur fichier txt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Valider(object sender, RoutedEventArgs e)
        {
            bool saisieCorrecte = true;
            List<TextBox> saisies = new List<TextBox> { WriteNomCompet, WriteCatégorie, WriteNiveau, WriteNbJoueursMin, WriteDurée, WriteDateDébut, WriteClassementMax };

            foreach(TextBox tb in saisies) { if (tb.Text == "") { saisieCorrecte = false; } }

            if(saisieCorrecte)
            {
                StreamWriter fichEcr = new StreamWriter(CompétitionFileName, true);

                foreach (TextBox tb in saisies)
                {
                    if (saisies.IndexOf(tb) != saisies.Count - 1)
                        fichEcr.Write(tb.Text + ";");
                    else
                        fichEcr.Write(tb.Text);
                }
                fichEcr.WriteLine();
                fichEcr.Close();

                Close();
            }
            else
            {
                MessageBox.Show("Saisie Incorrecte !");
            }

        }

        /// <summary>
        /// ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Annuler(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
