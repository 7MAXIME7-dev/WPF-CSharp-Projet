﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour InscrireQui.xaml
    /// </summary>
    public partial class InscrireQui : Window
    {
        bool selectMembre;

        /// <summary>
        /// constructeur de la fenetre warning pour choisir inscription membre ou salarié
        /// </summary>
        public InscrireQui()
        {
            InitializeComponent();           
        }

        /// <summary>
        /// instancie l'obj formulaire d'inscription pour un salarié
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Personnel(object sender, RoutedEventArgs e)
        {
            selectMembre = false;
            FormulaireInscription I = new FormulaireInscription(selectMembre);
            I.Show();
            Close();
        }

        /// <summary>
        ///  instancie l'obj formulaire d'inscription pour un membre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_membre(object sender, RoutedEventArgs e)
        {
            selectMembre = true;
            FormulaireInscription I = new FormulaireInscription(selectMembre);
            I.Show();
            Close();
        }
    }
}
