﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class TestProgram
    {
        static void Main(string[] args)
        {
            Club leclub = new Club();


        }
    }
}
