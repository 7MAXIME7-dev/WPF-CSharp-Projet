﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour FormulaireInscription.xaml
    /// </summary>
    public partial class FormulaireInscription : Window
    {
        static string[] labelsMembre = { "Nom", "Prenom", "Date de Naissance (JJ/MM/AAAA)", "Adresse", "Tel.", "Habite Dans La Ville Du Club ? (true/false)", "En Competition ? (true/false)", "Sexe (M / F)", "Classement (ex: 15,5)", "Email" };
        static string[] labelsPersonnel = { "Nom", "Prenom", "Date de Naissance (JJ/MM/AAAA)", "Adresse", "Tel.", "Sexe (M / F)", "RIB", "Salaire", "Est Salarié ? (true/false)", "Est Entraineur ? (true/false)" };

        static string PersonnelFileName = "Personnel.txt";
        static string MembresFileName = "Membres.txt";


        bool selectedMembre;
        static bool estEntraineur;
        int nbLignes;
        List<TextBox> referenceZoneTxt;

        /// <summary>
        /// Constructeur pour la fenetre d'inscription de Membre ou Salarié
        /// </summary>
        /// <param name="selectedMembre"> boolean qui permet de savoir si on va inscrire un Membre ou Salarié </param>
        public FormulaireInscription(bool selectedMembre)
        {
            this.selectedMembre = selectedMembre;
            this.nbLignes = 0;
            this.referenceZoneTxt = new List<TextBox>();
            InitializeComponent();
            AfficherGrille();
        }
           
        /// <summary>
        /// Affiche la grille avec à gauche les labels et à droites les champs à remplir
        /// </summary>
        private void AfficherGrille()
        {                                                        
            string[] labels = null;
            SolidColorBrush bleu = new SolidColorBrush(Color.FromArgb(0xFF, 0x33, 0x53, 0x6B));
            SolidColorBrush bleuClair = new SolidColorBrush(Color.FromArgb(0xFF, 0xA9, 0xBE, 0xC5));

            if (selectedMembre) { labels = labelsMembre; }
            else{ labels = labelsPersonnel; }

            nbLignes = labels.Length;
            int nbColonnes = 1;
            grid1.ShowGridLines = true;
            for (int l = 0; l < nbLignes; l++)
            {
                RowDefinition ligne = new RowDefinition();
                grid1.RowDefinitions.Add(ligne);
            }
            for (int c = 0; c < nbColonnes; c++)
            {
                ColumnDefinition colonne = new ColumnDefinition();
                grid1.ColumnDefinitions.Add(colonne);
            }


            // initialisation des labels
            for (int l = 0; l < nbLignes; l++)
            {
                Label lab = new Label();
                lab.FontSize = 15;
                lab.Foreground = Brushes.White;
                if (l % 2 != 0) { lab.Background = bleu; }
                else { lab.Background = bleuClair; }

                lab.Content = labels[l];
                Grid.SetRow(lab, l);       // positionnement sur ligne
                Grid.SetColumn(lab, 0);    // positionnement sur colonne
                grid1.Children.Add(lab);   // ajout au conteneur parent (la grille)
            }

            // initialisation des text box
            for (int l = 0; l < nbLignes; l++)
            {
                TextBox txtbox = new TextBox();
                if (l % 2 != 0) { txtbox.Background = bleu; }
                else { txtbox.Background = bleuClair; }
           
                txtbox.Foreground = Brushes.Red;
                txtbox.FontSize = 15;
                referenceZoneTxt.Add(txtbox);
                Grid.SetRow(txtbox, l);       // positionnement sur ligne
                Grid.SetColumn(txtbox, 1);    // positionnement sur colonne
                grid1.Children.Add(txtbox);   // ajout au conteneur parent (la grille)
            }

            Button annuler = new Button(); // Création d'un bouton associé à une carte 
            annuler.Content = "Annuler";
            Grid.SetRow(annuler, labels.Length);       // positionnement sur ligne
            Grid.SetColumn(annuler, 0);    // positionnement sur colonne
            grid1.Children.Add(annuler);

            Button valider = new Button(); // Création d'un bouton associé à une carte 
            valider.Content = "Valider";
            Grid.SetRow(valider, labels.Length);       // positionnement sur ligne
            Grid.SetColumn(valider, 1);    // positionnement sur colonne
            grid1.Children.Add(valider);
            valider.Click += Button_Valider;
            annuler.Click += Button_Annuler;
        }

        /// <summary>
        /// inscrit dans le fichier txt le nouveau membre ou salarié
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Valider(object sender, RoutedEventArgs e)
        {
            bool saisieCorrecte = true;
          

            foreach (TextBox tb in referenceZoneTxt) { if (tb.Text == "") { saisieCorrecte = false; } }

            if(saisieCorrecte)
            {
                string file_name = "";
                          
                List<string> ancienneEcriture = new List<string>();

                if (selectedMembre) { file_name = MembresFileName; }
                else 
                { 
                    file_name = PersonnelFileName; 
                    estEntraineur = bool.Parse(referenceZoneTxt[9].Text); 
                }


                StreamWriter fichEcr = new StreamWriter(file_name, true);
                
                foreach (TextBox tb in referenceZoneTxt)
                {
                    ancienneEcriture.Add(tb.Text);
                    fichEcr.Write(tb.Text + ";");
                }

                if (selectedMembre)
                {
                    //cotisation pas payé
                    fichEcr.WriteLine("false;");
                }
                else
                {   // inscrire la date du jour comme date d'entrée
                    DateTime today = DateTime.Now;
                    fichEcr.WriteLine(today.Day + "/" + today.Month + "/" + today.Year);
                }
                fichEcr.Close();
                Close();


                if (estEntraineur)
                {
                    FormulaireInscription formForEntraineur = new FormulaireInscription(true);
                    formForEntraineur.Show();
                    for (int i = 0; i < 5; i++)
                    {
                        formForEntraineur.referenceZoneTxt[i].Text = ancienneEcriture[i];
                    }
                    estEntraineur = false;
                }           
               
            }
            else
            {
                MessageBox.Show("Saisie Incorrecte ! ");
            }

        }

        /// <summary>
        /// ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Annuler(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
