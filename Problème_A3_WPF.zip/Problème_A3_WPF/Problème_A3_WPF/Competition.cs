﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class Competition : Evènement
    {     
        // catégorie = femmes hommes junior
        char catégorie;
        //niveau regional, départemental
        string niveau;
        int nbJoueursMin;
           
        string classementMax;
        List<Match> matchs;
        

        public Competition(string nom, char catégorie, string niveau, int nbJoueursMin, int duree, DateTime debut, string classementMax, List<Match> matchs)
            :base(nom, debut, duree)
        {            
            this.catégorie = catégorie;
            this.niveau = niveau;
            this.nbJoueursMin = nbJoueursMin;
            this.classementMax = classementMax;
            this.matchs = matchs;
        }

        public string ClassementMax { get { return this.classementMax.ToUpper().Replace(" ", ""); } }
        public char Catégorie { get { return this.catégorie; } }
        public string Niveau { get { return this.niveau; } }
        public int NbJoueursMin{ get { return this.nbJoueursMin; } }       
        public List<Match> Matchs { get { return this.matchs; } }

        public string DateDébutToString()
        {
            return Début.Day + "/" + Début.Month + "/" + Début.Year;
      
        }

        public override string ToString()
        {
            return "Compétition " + base.ToString();
        }

    }
}
