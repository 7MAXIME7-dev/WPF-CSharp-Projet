﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour GestionMembre.xaml
    /// </summary>
    public partial class GestionMembre : Window
    {
        Club leClub;      
        List<string> onTrie;
        bool estHomme;
        bool estLoisir;

        /// <summary>
        /// Constructeur pour la fenêtre Membre
        /// </summary>
        public GestionMembre()
        {
            this.estHomme = true;
            this.estLoisir = true;
            InitializeComponent();
            this.leClub = new Club();
            this.onTrie = new List<string> { "Liste Complète", "Loisir/Compétition", "Ordre Alphabétique", "Par Classement", "Par Sexe", "Doit Payer", "..." };

            trierPar.ItemsSource = onTrie;
            
            trierPar.SelectedIndex = 0;
        }


        /// <summary>
        /// gère l'affichage de la liste des Membres
        /// </summary>
        private void AfficherListeMembre()
        {
            List<Membre> memberList = this.leClub.LesMembres;

            if (memberList.Count != 0)
            {
                foreach (Membre me in memberList) { ListeDesMembres.Items.Add(me.Prenom + " " + me.Nom); }
                ListeDesMembres.SelectedItem = memberList[0].Prenom + " " + memberList[0].Nom;
            }
            else
            {
                MessageBox.Show("Aucun Membre !");
            }
        }

        /// <summary>
        /// Lorqu'on selectionne un membre, on affiche les infos correspondantes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListBox_Membres(object sender, SelectionChangedEventArgs e)
        {    
           
            int index_selectionne = ListeDesMembres.SelectedIndex;

            if (index_selectionne >= 0)
            {
                Membre information = this.leClub.LesMembres[index_selectionne];

                ShowNom.Text = information.Nom;
                ShowPrenom.Text = information.Prenom;
                ShowAdresse.Text = information.Adresse;
                ShowDdn.Text = information.DateToString(information.DateNaissance);
                ShowNumero.Text = information.Numero;
                ShowaPayer.Text = information.Cotisation.ToString();
                ShowCotisation.Text = information.CotisationPaye.ToString();
                ShowSexe.Text = information.Sexe.ToString();
                ShowCompetiton.Text = information.EnCompetiton + " => Classement : " + information.Classement;
                ShowAge.Text = information.Age().ToString();

            }

        }

        /// <summary>
        /// Nettoie la listbox de tous les membres
        /// </summary>
        private void SupprimerListeMembres()
        {
            List<Membre> memberList = this.leClub.LesMembres;
            if (memberList.Count != 0)
            {
                foreach (Membre me in memberList) { ListeDesMembres.Items.Remove(me.Prenom + " " + me.Nom); }
                ListeDesMembres.SelectedItem = memberList[0].Prenom + " " + memberList[0].Nom;
            }
        }

        /// <summary>
        /// Affiche la liste des membres qui nous interresent jusqu'à un index ( pour les tries )
        /// </summary>
        /// <param name="nb"> c'est l'index </param>
        private void AfficherListeMembresJusqua(int nb)
        {
            for (int index = 0; index < nb; index++)
            {
                ListeDesMembres.Items.Add(leClub.LesMembres[index].Prenom + " " + leClub.LesMembres[index].Nom);
            }
            ListeDesMembres.SelectedItem = leClub.LesMembres[0].Prenom + " " + leClub.LesMembres[0].Nom;
        }

        /// <summary>
        /// ce bouton supprime le membre selectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Suppr_Click(object sender, RoutedEventArgs e)
        {
            Membre selected = this.leClub.LesMembres[ListeDesMembres.SelectedIndex];
            this.leClub.LesMembres.Remove(selected);
            ListeDesMembres.Items.Remove(selected.Prenom + " " + selected.Nom);
        }

        /// <summary>
        ///  ce bouton permet de faire payer la cotisation du membre selectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Payer_Click(object sender, RoutedEventArgs e)
        {
            Membre selected = this.leClub.LesMembres[ListeDesMembres.SelectedIndex];
            selected.CotisationPaye = true;
            ShowCotisation.Text = selected.CotisationPaye.ToString();            
        }

        /// <summary>
        /// en fonction de l'élément choisi s'applique un trie sur la liste ( les tries sont dans la classe Club )
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_Trier(object sender, SelectionChangedEventArgs e)
        {
   
            if (trierPar.SelectedIndex == 0)
            {                
                SupprimerListeMembres();
                AfficherListeMembre();
                trierPar.Text = onTrie[0];
            }

            if(trierPar.SelectedIndex == 1)
            {
                SupprimerListeMembres();
                int nb = leClub.TrieLoisirCompetition(estLoisir);

                AfficherListeMembresJusqua(nb);

                if (estLoisir) { estLoisir = false; } else { estLoisir = true; }

                // change l'index sinon on ne peut pas directement passer de Loisir vers Competition et inversement
                trierPar.SelectedIndex = 6;              
            }

            if (trierPar.SelectedIndex == 2)
            {
                SupprimerListeMembres();
                leClub.TrieOrdreAlphabétique();               
                AfficherListeMembre();
            }

            if (trierPar.SelectedIndex == 3)
            {
                SupprimerListeMembres();
                leClub.TrieClassement();
                AfficherListeMembre();
            }

            if (trierPar.SelectedIndex == 4)
            {               
                int nb = leClub.TrieParSexe(estHomme);
                SupprimerListeMembres();

                AfficherListeMembresJusqua(nb);

                if (estHomme) { estHomme = false; } else { estHomme = true; }

                trierPar.SelectedIndex = 6;
            }

            if(trierPar.SelectedIndex == 5)
            {
                SupprimerListeMembres();
                int nb = leClub.TrieParDoitPayer();
                AfficherListeMembresJusqua(nb);
                
                
            }
        }

        /// <summary>
        /// remet à Non Payé toutes les cotisations (pour une nouvelle année par exemple)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Maj_Cotisation(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Membre information = this.leClub.LesMembres[index_selectionne];

            
            foreach (Membre m in this.leClub.LesMembres)
            {              
                m.CotisationPaye = false;
            }

            ShowCotisation.Text = information.CotisationPaye.ToString();          
        }

        /// <summary>
        /// Button pour fermer la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Bouton qui enregistre tous les membres dans le fichier txt et ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Enregistrer(object sender, RoutedEventArgs e)
        {
            leClub.EnregistrementFichierMembre();
            Close();
        }

        /// <summary>
        /// Button "ok" qui permet de changer l'adresse d'un obj Membre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Changer_Adresse(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Membre information = this.leClub.LesMembres[index_selectionne];
            information.Adresse = ShowAdresse.Text;
        }

        /// <summary>
        /// Button "ok" qui permet de changer le numéro d'un obj Membre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Changer_Numero(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Membre information = this.leClub.LesMembres[index_selectionne];
            information.Numero= ShowNumero.Text;
        }

        private void TextBox_Email(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_RelanceParMail(object sender, RoutedEventArgs e)
        {
            int nb = leClub.TrieParDoitPayer();

            for (int index = 0; index < nb; index++)
            {
                leClub.LesMembres[index].EnvoiRelance(WriteMail.ToString(), WriteMDP.ToString());
            }
        }

        private void TextBox_MDP(object sender, TextChangedEventArgs e)
        {

        }
    }
}
