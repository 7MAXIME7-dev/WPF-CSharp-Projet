﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour GestionCompétition.xaml
    /// </summary>
    public partial class GestionCompétition : Window
    {
        Club leClub;
        static List<string> typeMatch = new List<string> { "...", "Simple", "Double" };

        // -2 est la valeur qui indique que le match n'a pas encore de score
        static List<int> scoreSimple = new List<int> { -2, -1, 0, 2 };
        static List<int> scoreDouble = new List<int> { -2, -1, 0, 1 };

        /// <summary>
        /// Constructeur pour la fenêtre Compétitions
        /// </summary>
        public GestionCompétition()
        {
            this.leClub = new Club();
            InitializeComponent();
            AffichageCompetition();
            ComboLesCompétition.SelectedIndex = 0;
            ComboTypeDeMatch.ItemsSource = typeMatch; 
              
        }


        /// <summary>
        /// enlève tous les éléments de la liste d'equipe
        /// </summary>
        private void SupprimerListeEquipe()
        {
            List<Membre> memberList = this.leClub.LesMembres;
            if (memberList.Count != 0)
            {
                foreach (Membre me in memberList) { ListeEquipe.Items.Remove(me.Prenom + " " + me.Nom); }
                
            }
            ListeEquipe.SelectedItem = memberList[0].Prenom + " " + memberList[0].Nom;
        }

        /// <summary>
        /// Ajoute au Combo tous les noms de compétition
        /// </summary>
        private void AffichageCompetition()
        {
            List<string> nomCompetition = new List<string>();
            foreach(Competition c in this.leClub.LesCompétitions)
            {
                nomCompetition.Add(c.Nom);
            }

            ComboLesCompétition.ItemsSource = nomCompetition;
        }

        /// <summary>
        /// affiche tous les joueurs éligibles à une compétition en fct de l'age, Catégorie, classement 
        /// </summary>
        private void AffichageJoueursEligible()
        {
            List<Membre> listeBrut = this.leClub.LesMembres;

            int indexSelected = ComboLesCompétition.SelectedIndex;
            Competition laCompétition = this.leClub.LesCompétitions[indexSelected];

            List<string> compétiteurs = new List<string>();

            if(laCompétition.Catégorie == 'J')
            {
                listeBrut = listeBrut.FindAll(a => a.Age() < 18);
            }
            else
            {
                if (laCompétition.Catégorie == 'H') 
                {
                    listeBrut = listeBrut.FindAll(a => a.Sexe == 'M');
                    listeBrut = listeBrut.FindAll(a => a.Age() >= 18);
                }

                else
                {
                    listeBrut = listeBrut.FindAll(a => a.Sexe == 'F');
                    listeBrut = listeBrut.FindAll(a => a.Age() >= 18);
                }
            }


            listeBrut = listeBrut.FindAll(a => a.EnCompetiton == true);

            if (laCompétition.ClassementMax != "TOP100")
            {
                // récupération des non classé (éviter des erreurs de type au moment de la condition sur des entiers)
                List<Membre> NonClassé = listeBrut.FindAll(a => a.Classement == "NC");
                

                // enlevement des NC et top100 puisqu'ils n'appartiendront pas a la liste
                listeBrut.RemoveAll(a => a.Classement == "NC" || a.Classement == "TOP100");


                // récuperation des membres avec classement <= classement max
                listeBrut = listeBrut.FindAll(a => Convert.ToDouble(a.Classement) >= Convert.ToDouble(laCompétition.ClassementMax));

                // réintroduction des NC
                listeBrut = listeBrut.Concat(NonClassé).ToList();
            }


            foreach (Membre me in listeBrut) { compétiteurs.Add(me.Prenom + " " + me.Nom); }
            this.ListeDesCompétiteurs.ItemsSource = compétiteurs;

            ListeDesCompétiteurs.SelectedIndex = 0;

            TimeSpan date = DateTime.Now - laCompétition.Début;
            //ListeDesCompétiteurs.IsEnabled = true;

            if (date.TotalDays < 0) 
            { 
                ListeDesCompétiteurs.IsEnabled = true; 
                ButtonAjouterMembre.IsEnabled = true; 
            }
            else 
            {
                ListeDesCompétiteurs.IsEnabled = false; 
                ButtonAjouterMembre.IsEnabled = false; 
            }
        }

        /// <summary>
        /// Ajoute a la liste d'equipe tous les noms de joueurs inscrits
        /// </summary>
        private void AffichageJoueursEquipe()
        {
            SupprimerListeEquipe();
            ShowDateRencontre.Text = "";
            int indexSelected = ComboLesCompétition.SelectedIndex;
            Competition laCompétition = this.leClub.LesCompétitions[indexSelected];

            foreach (Match m in laCompétition.Matchs) { ListeEquipe.Items.Add(m.PrenomJoueur + " " + m.NomJoueur); }   

            if(laCompétition.Matchs.Count < laCompétition.NbJoueursMin)
            {
                int manque = laCompétition.NbJoueursMin - laCompétition.Matchs.Count;
                ShowZoneInformation.Text = "Il manque " + manque + " joueur(s) pour valider la compétition...";
            }
            else
            {
                ShowZoneInformation.Text = "";
            }
            
        }

        /// <summary>
        /// Rend disponible ou non certains éléments de la fenêtre qui dépendent de la date de rencontre d'un match
        /// </summary>
        private void EnableResultatMatch()
        {
            int indexSelected1 = ComboLesCompétition.SelectedIndex;
            int indexSelected2 = ListeEquipe.SelectedIndex;
            Match leMatch = this.leClub.LesCompétitions[indexSelected1].Matchs[indexSelected2];

            TimeSpan date = DateTime.Now - leMatch.DateDeRencontre;

            if (date.TotalDays < 0)
            {
                ComboRésultat.IsEnabled = false;
                ComboTypeDeMatch.IsEnabled = true;
                ShowDateRencontre.IsEnabled = true;
                ButtonOK.IsEnabled = true;
            }
            else
            {
                ComboRésultat.IsEnabled = true;
                ComboTypeDeMatch.IsEnabled = false;
                ShowDateRencontre.IsEnabled = false;
                ButtonOK.IsEnabled = false;
            }
        }

        /// <summary>
        /// Affiche les informations lié à la Compétition selectionnée
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_choixCompetition(object sender, SelectionChangedEventArgs e)
        {     
            int indexSelected = ComboLesCompétition.SelectedIndex;
            Competition laCompétition = this.leClub.LesCompétitions[indexSelected];
            ShowNiveau.Text = laCompétition.Niveau;
            ShowNbJoueurs.Text = laCompétition.NbJoueursMin.ToString();
            ShowDurée.Text = laCompétition.Duree.ToString();
            ShowDébut.Text = laCompétition.DateDébutToString();
            ShowCatégorie.Text = laCompétition.Catégorie.ToString();
            ShowClassementMax.Text = laCompétition.ClassementMax.ToString();

            AffichageJoueursEligible();
            AffichageJoueursEquipe();
            ListeEquipe.SelectedIndex = 0;
        }

        /// <summary>
        /// ne fait rien
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListBox_JoueursCompatibleCompet(object sender, SelectionChangedEventArgs e)
        {

        }

        /// <summary>
        ///  Renseigne les informations de match dès qu'un joueur est selectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListBox_Joueurs(object sender, SelectionChangedEventArgs e)
        {

            int indexSelected1 = ComboLesCompétition.SelectedIndex;
            int indexSelected2 = ListeEquipe.SelectedIndex;
            ComboTypeDeMatch.SelectedItem = "...";
            

            if (indexSelected2 != -1 && indexSelected2 < this.leClub.LesCompétitions[indexSelected1].Matchs.Count)
            {
                Match leMatch = this.leClub.LesCompétitions[indexSelected1].Matchs[indexSelected2];
                ComboRésultat.SelectedItem = leMatch.ResultatRencontre;
                EnableResultatMatch();
                if (leMatch.EstSimple) { ComboTypeDeMatch.SelectedItem = "Simple"; }
                else { ComboTypeDeMatch.SelectedItem = "Double"; }
                ComboRésultat.SelectedItem = leMatch.ResultatRencontre;
                ShowDateRencontre.Text = leMatch.DateDeRencontreToString();
            }
        }

        /// <summary>
        /// permet de changer le resultat d'un obj Match
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_RésultatMatch(object sender, SelectionChangedEventArgs e)
        {
            int indexSelected1 = ComboLesCompétition.SelectedIndex;
            int indexSelected2 = ListeEquipe.SelectedIndex;
          
            Match leMatch = this.leClub.LesCompétitions[indexSelected1].Matchs[indexSelected2];
            leMatch.ResultatRencontre = (int)ComboRésultat.SelectedItem;

        }

        /// <summary>
        /// Change le type de score en fonction du type de match choisi
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_TypeDeMatch(object sender, SelectionChangedEventArgs e)
        {
            if ((string)ComboTypeDeMatch.SelectedItem == typeMatch[1]) { ComboRésultat.ItemsSource = scoreSimple; }
            if ((string)ComboTypeDeMatch.SelectedItem == typeMatch[2]) { ComboRésultat.ItemsSource = scoreDouble; }


        }

        /// <summary>
        /// Permet l'ajout d'un Membre à la liste de l'equipe
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_AjouterACompétition(object sender, RoutedEventArgs e)
        {
            string MembreSelected = (string)ListeDesCompétiteurs.SelectedItem;

            if(!(ListeEquipe.Items.Contains(MembreSelected))) 
            {
                ShowDateRencontre.Text = "";
                ListeEquipe.Items.Add(MembreSelected);
                ShowZoneInformation.Text = "Veillez saisir le Type de Match et la Date de Rencontre, Puis Click sur OK... \nTOUTE SAISIE EST DEFINITIVE !!";
                ListeEquipe.SelectedItem = MembreSelected;
                ListeEquipe.IsEnabled = false;
                ButtonAjouterMembre.IsEnabled = false;
                
            }
        }

        /// <summary>
        ///  ajout du Membre par la création d'un match
        ///  avant cela vérification que le membre n'appartient pas déjà à l'équipe 
        ///  et vérification de non colision avec les autres dates sur d'autres compétitions (si le joueur joue dans une autre compet) 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_OK(object sender, RoutedEventArgs e)
        {
            if(ComboTypeDeMatch.SelectedItem.ToString() != "..." && ShowDateRencontre.Text != "")
            {
                bool collision = false;

                string MembreSelected = (string)ListeEquipe.SelectedItem;
                int indexSelected1 = ComboLesCompétition.SelectedIndex;
               
                string[] nom = MembreSelected.Split(' ');
                string[] date = ShowDateRencontre.Text.Split('/');
                DateTime dateRencontre = leClub.CreationDate(int.Parse(date[0]), int.Parse(date[1]), int.Parse(date[2]));


                foreach (Competition compet in leClub.LesCompétitions)
                    foreach(Match mat in compet.Matchs)
                    {
                        if(mat.PrenomJoueur + " " + mat.NomJoueur == ListeEquipe.SelectedItem.ToString())
                        {
                            if(mat.DateDeRencontre == dateRencontre) { collision = true; }                           
                        }
                    }


                if (collision)
                {
                    ShowZoneInformation.Text = "La Date de Rencontre est en Collision avec un Autre Match ! Changez de Date, Puis, Reesayez.";
                }
                else
                {
                    bool estSimple = true;
                    if ((string)ComboTypeDeMatch.SelectedItem == typeMatch[2]) { estSimple = false; }

                    Match nouveau = new Match(nom[1], nom[0], -2, estSimple, dateRencontre);
                    this.leClub.LesCompétitions[indexSelected1].Matchs.Add(nouveau);
                    ListeEquipe.IsEnabled = true;
                    ButtonAjouterMembre.IsEnabled = true;
                    ShowZoneInformation.Text = "Membre Ajouté avec Succès !";
                }

            }
            else
            {
                ShowZoneInformation.Text = "Information(s) Manquant(ent)... Veuillez réessayer";
            }

        }

        /// <summary>
        /// ne fait rien
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_DateRencontre(object sender, TextChangedEventArgs e)
        {

        }

        /// <summary>
        /// ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// enregistre toutes les compétitions dans le fichier txt puis ferme la fenetre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_EnregistrerQuitter(object sender, RoutedEventArgs e)
        {
            leClub.EnregistrementFichierCompetitions();
            Close();
        }
    }
}
