﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    class Salarié : Acteur
    {
        string rib;
        int salaire;
        DateTime dateEntree;

        public Salarié(string nom, string prenom, DateTime dateNaissance, string adresse, string numero, char sexe, string rib, int salaire, DateTime dateEntree) 
            : base(nom, prenom, dateNaissance, adresse, numero, sexe)
        {
            this.rib = rib;
            this.salaire = salaire;
            this.dateEntree = dateEntree;
        }

        public string Rib { get { return rib.ToUpper(); } }
        public int Salaire { get { return salaire; } }
        public DateTime DateEntree { get { return dateEntree; } }
    }
}
