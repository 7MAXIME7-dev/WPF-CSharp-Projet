﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;

namespace Problème_A3_WPF
{
    class Membre : Acteur, IComparable
    {
        int cotisation;
        bool cotisationPaye;
        bool habiteDansVilleDuClub;
        // true = competiton, false = loisir
        bool enCompetition;
        string classement;
        string mail;

        public Membre(string nom, string prenom, DateTime dateNaissance, string adresse, string numero, bool habiteDansVilleDuClub, bool enCompetition, char sexe, string classement, string mail)
            : base(nom, prenom, dateNaissance, adresse, numero, sexe)
        {
            this.cotisation = 0;
            this.cotisationPaye = false;
            this.habiteDansVilleDuClub = habiteDansVilleDuClub;
            this.enCompetition = enCompetition;
            this.classement = classement;
            this.mail = mail;
        }

        public bool HabiteDansVilleDuClub { get { return this.habiteDansVilleDuClub; } set { this.habiteDansVilleDuClub = value; } }
        public int Cotisation { get { return this.CalculDeLaCotisation(); } }
        public bool CotisationPaye { get { return this.cotisationPaye; } set { this.cotisationPaye = value; } }
        public bool EnCompetiton { get { return this.enCompetition; } set { this.enCompetition = value; } }
        public string Classement { get { return this.classement.ToUpper().Replace(" ", ""); } set { this.classement = value; } }
        public string Mail { get { return this.mail; } }


        /// <summary>
        /// permet de comparer 2 Membre en fonction de leur classement 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>un entier</returns>
        public int CompareTo(object obj)
        {
            Membre m;
            if ((obj is Membre) && (obj != null))
            {
                m = (Membre)obj;
                //ordre décroissant
                return -double.Parse(this.classement).CompareTo(double.Parse(m.classement));
            }
            else
                return 1;
        }

        /// <summary>
        /// permet de calculer la cotisation d'un membre en fct de son age et de sa ville 
        /// </summary>
        /// <returns>un entier : la cotisation</returns>
        public int CalculDeLaCotisation()
        {
            if (this.habiteDansVilleDuClub)
            {
                if (this.Age() >= 18)
                {
                    return 200;
                }
                else
                {
                    return 130;
                }
            }
            else
            {
                if (this.Age() >= 18)
                {
                    return 280;
                }
                else
                {
                    return 180;
                }
            }
        }


        /// <summary>
        /// envoie une relance a un membre
        /// </summary>
        /// <param name="from">email (string)</param>
        /// <param name="fromPassword">mot de passe (string)</param>
        public void EnvoiRelance(string from, string fromPassword)
        {
            var fromAddress = new MailAddress(from);
            var toAddress = new MailAddress(this.mail, "");

            const string subject = "Relance Club de Tennis";
            string body = "Bonjour,\n\n" +
                "Nous vous rappellons que vous devez régler un montant de " + this.Cotisation + " pour l'année " + DateTime.Now.Year + " au plus vite." +
                "\n\nCordialement," +
                "\n Le Club";
            

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword),
                Timeout = 20000
            };
            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            })
            {
                smtp.Send(message);
            }
        }

        public override string ToString()
        {
            return base.ToString()
                + "\nCotisation                   : " + this.cotisation
                + "\nCotisation Payée ?           : " + this.cotisationPaye;
        }
    }
}
