﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Problème_A3_WPF
{
    /// <summary>
    /// Logique d'interaction pour GestionMembre.xaml
    /// </summary>
    public partial class GestionSalarié : Window
    {
        Club leClub;

        public GestionSalarié()
        {
            this.leClub = new Club(); 

            InitializeComponent();
        

            if(this.leClub.LesSalariés.Count != 0)
            {
                foreach (Salarié s in this.leClub.LesSalariés){ ListeDesMembres.Items.Add(s.Prenom + " " + s.Nom); }
                ListeDesMembres.SelectedItem = this.leClub.LesSalariés[0].Prenom + " " + this.leClub.LesSalariés[0].Nom;
            }
            else
            {
                MessageBox.Show("Aucun Membre !");                
            }                                               
        }

        static List<int> ToIntDate(string[] date)
        {
            // convertion des elements string en int
            List<int> intdate = new List<int>();
            foreach (string e in date) { intdate.Add(Convert.ToInt32(e)); }

            return intdate;
        }

        static DateTime CreationDate(int jour, int mois, int annee)
        {
            DateTime date = new DateTime(day: jour, month: mois, year: annee);
            return date;
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {    
           
            int index_selectionne = ListeDesMembres.SelectedIndex;

            if (index_selectionne >= 0)
            {
                Salarié information = this.leClub.LesSalariés[index_selectionne];

                ShowNom.Text = information.Nom;
                ShowPrenom.Text = information.Prenom;
                ShowAdresse.Text = information.Adresse;
                ShowDdn.Text = information.StrDate(information.DateNaissance);
                ShowNumero.Text = information.Numero;
                ShowRib.Text = information.Rib;
                ShowSalaire.Text = information.Salaire.ToString();
                ShowDateEntree.Text = information.StrDate(information.DateEntree);

            }

        }

        private void Button_Suppr_Click(object sender, RoutedEventArgs e)
        {
            Salarié selected = this.leClub.LesSalariés[ListeDesMembres.SelectedIndex];
            this.leClub.LesSalariés.Remove(selected);
            ListeDesMembres.Items.Remove(selected.Prenom + " " + selected.Nom);
        }

        private void Button_Quitter(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Enregistrer(object sender, RoutedEventArgs e)
        {
            leClub.EnregistrementFichierSalariés();
            Close();
        }

        private void Button_Changer_Adresse(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Salarié information = this.leClub.LesSalariés[index_selectionne];
            information.Adresse = ShowAdresse.Text;
        }

        private void Button_Changer_Numero(object sender, RoutedEventArgs e)
        {
            int index_selectionne = ListeDesMembres.SelectedIndex;
            Salarié information = this.leClub.LesSalariés[index_selectionne];
            information.Numero= ShowNumero.Text;
        }
    }
}
