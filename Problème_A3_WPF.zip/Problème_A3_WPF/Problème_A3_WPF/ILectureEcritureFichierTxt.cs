﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    interface ILectureEcritureFichierTxt
    {
        public DateTime CreationDate(int jour, int mois, int annee);
        public List<int> ToIntDate(string[] date);
        public List<Membre> LectureFichierMembre();
        public List<Personnel> LectureFichierPersonnel();
        public void EnregistrementFichierMembre();
        public void EnregistrementFichierPersonnel();
        public List<Competition> LectureFichierCompetitions();
        public void EnregistrementFichierCompetitions();


    }
}
