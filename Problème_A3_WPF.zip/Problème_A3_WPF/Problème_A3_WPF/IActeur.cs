﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problème_A3_WPF
{
    interface IActeur
    {
        public int Age();

        public string StrDate(DateTime d)

    }
}
