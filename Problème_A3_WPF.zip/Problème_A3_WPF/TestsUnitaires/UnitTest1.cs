﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Problème_A3_WPF
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            GestionMembre GestM = new GestionMembre();


            Club b = new Club();
            
      
            DateTime date = new DateTime(day: 1, month: 1, year: 2019);
           // Assert.AreEqual(GestM.CreationDate(1, 1, 2019), date);


            


        }
    }
}
